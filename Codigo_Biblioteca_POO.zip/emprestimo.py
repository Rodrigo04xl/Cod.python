
class Emprestimo:
    def __init__(self, livro, usuario):
        self.livro = livro
        self.usuario = usuario

    def realizar(self):
        if self.livro.emprestar():
            return f"Livro '{self.livro.titulo}' emprestado para {self.usuario.nome}"
        return "Livro indisponível"

    def finalizar(self):
        self.livro.devolver()
        return f"Livro '{self.livro.titulo}' devolvido com sucesso"
