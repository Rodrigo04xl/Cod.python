
class Usuario:
    def __init__(self, nome, matricula):
        self.nome = nome
        self.matricula = matricula

    def detalhes(self):
        return f"{self.nome} - Matrícula: {self.matricula}"
