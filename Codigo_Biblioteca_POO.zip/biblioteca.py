
from livro import Livro
from usuario import Usuario
from emprestimo import Emprestimo

class Biblioteca:
    def __init__(self):
        self.livros = []
        self.usuarios = []

    def adicionar_livro(self, livro):
        self.livros.append(livro)

    def cadastrar_usuario(self, usuario):
        self.usuarios.append(usuario)

    def listar_livros(self):
        for livro in self.livros:
            print(livro.detalhes())


if __name__ == "__main__":
    biblioteca = Biblioteca()

    livro1 = Livro("Dom Casmurro", "Machado de Assis", 101)
    usuario1 = Usuario("Jorge", "2026001")

    biblioteca.adicionar_livro(livro1)
    biblioteca.cadastrar_usuario(usuario1)

    emprestimo = Emprestimo(livro1, usuario1)

    print(emprestimo.realizar())
    biblioteca.listar_livros()
    print(emprestimo.finalizar())
